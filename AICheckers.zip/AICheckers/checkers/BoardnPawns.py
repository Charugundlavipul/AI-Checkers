import pygame
from  checkers.fixedValues import *
# from .piece import Piece
from copy import deepcopy

class Board:
    
    def __init__(self):
        # self.window = window
        self.board = []
        self.redRemaining = 12
        self.blueRemaining = 12
        self.redKings = 0
        self.blueKings = 0
        self.fillInitialPieces()
        
    
    def drawBoard(self,window):
        window.fill(BROWN)
        for row in range(ROWS):
            for col in range(row%2, COLUMNS, 2):
                pygame.draw.rect(window, PEACH, (row*100, col*100, TILE_SIZE, TILE_SIZE))
    
    def fillInitialPieces(self):
        for row in range(ROWS):
            self.board.append([])
            for col in range(COLUMNS):
                if row%2 != col%2:
                    if row < 3:
                        self.board[row].append(Piece(row,col,LIGHTBLUE))
                    elif row > 4:
                        self.board[row].append(Piece(row,col,LIGHTRED))
                    else:
                        self.board[row].append(0)
                else:
                    self.board[row].append(0)
    
    def fillPieces(self,window):
        self.drawBoard(window)
        for row in range(ROWS):
            for col in range(COLUMNS):
                if self.board[row][col] != 0:
                    self.board[row][col].drawPiece(window)
    
    def getPiece(self, row, col):
        return self.board[row][col]

    def movePiece(self, piece, row, col):
        temp = self.board[piece.row][piece.col]
        self.board[piece.row][piece.col] = 0
        self.board[row][col] = temp
        self.board[row][col].updatePosition(row, col)
        # piece.updatePosition(row, col)
        if row == ROWS-1 or row == 0:
            if self.board[row][col].king == False:
                self.board[row][col].makeKing()
                if self.board[row][col].color == LIGHTRED:
                    self.redKings += 1
                else:
                    self.blueKings += 1

    
    def removePieces(self, skipped):
        for skip in skipped:
            self.board[skip.row][skip.col] = 0
            if skip != 0:
                if skip.color == LIGHTRED:
                    self.redRemaining -= 1
                    if skip.king:
                        self.redKings -= 1
                else:
                    self.blueRemaining -= 1
                    if skip.king:
                        self.blueKings -= 1

    def getValidSpaces(self, piece, killPieces=[]):
        validSpaces = {}
        left = piece.col - 1
        right = piece.col + 1
        row = piece.row
        
        if piece.color == LIGHTRED and piece.king == False:
            validSpaces.update(self.checkLeft(row-1, max(row-3,-1), -1, piece.color, left))
            validSpaces.update(self.checkRight(row-1,max(row-3,-1), -1, piece.color, right))
        if piece.color == LIGHTBLUE and piece.king == False:
            validSpaces.update(self.checkLeft(row+1, min(row+3,ROWS), 1, piece.color, left))
            validSpaces.update(self.checkRight(row+1,min(row+3,ROWS), 1, piece.color, right))
        if piece.king:
            validSpaces.update(self.checkKingLeft(row+1, min(row+3,ROWS), 1, piece.color, left))
            validSpaces.update(self.checkKingRight(row+1,min(row+3,ROWS), 1, piece.color, right))
            validSpaces.update(self.checkKingLeft(row-1, max(row-3,-1), -1, piece.color, left))
            validSpaces.update(self.checkKingRight(row-1,max(row-3,-1), -1, piece.color, right))

        row1, col1 = piece.row, piece.col
        poptups = []
        if len(killPieces) > 0:
            if (row1,col1) in killPieces:
                for (row,col) in validSpaces.keys():
                    skipped = validSpaces[(row,col)]
                    if len(skipped) == 0:
                        poptups.append((row,col))
            if len(poptups) > 0:
                for tup in poptups:
                    validSpaces.pop(tup)
        
        return validSpaces

    def checkLeft(self, begin, end, step, color, left, skipped=[]):
        validSpaces = {}
        last = []
        key = ()
        for row in range(begin, end, step):
            if left < 0:
                break
            current = self.board[row][left]
            if current == 0:
                if skipped and not last:
                    break
                elif skipped:
                    validSpaces[(row, left)] = skipped+last
                    skipped += last
                    key = (row,left)
                else:
                    validSpaces[(row, left)] = last
                    key = (row,left)
                
                if last:
                    if step == 1:
                        rows = min(row+3,ROWS)
                    else:
                        rows = max(row-3,-1)
                    
                    if len(skipped) == 0:
                        skipped = last

                    siz = len(validSpaces)
                    validSpaces.update(self.checkLeft(row+step, rows, step, color, left-1, deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        validSpaces.pop(key)
                    siz = len(validSpaces)
                    validSpaces.update(self.checkRight(row+step,rows, step, color, left+1,deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        if(key in validSpaces.keys()):
                            validSpaces.pop(key)
                break
            
            elif current.color == color:
                break
            else:
                last = [current]
            
            left -= 1

        return validSpaces

    def checkRight(self, begin, end, step, color, right, skipped=[]):
        validSpaces = {}
        last = []
        key = ()
        for row in range(begin, end, step):
            if right >= COLUMNS:
                break
            current = self.board[row][right]
            if current == 0:
                if skipped and not last:
                    break
                elif skipped:
                    validSpaces[(row, right)] = skipped+last
                    skipped += last
                    key = (row,right)
                else:
                    validSpaces[(row, right)] = last
                    key = (row, right)
                
                if last:
                    if step == 1:
                        rows = min(row+3,ROWS)
                    else:
                        rows = max(row-3,-1)
                    
                    if len(skipped) == 0:
                        skipped = last

                    siz = len(validSpaces)
                    validSpaces.update(self.checkLeft(row+step, rows, step, color, right-1, deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        validSpaces.pop(key)
                    siz = len(validSpaces)
                    validSpaces.update(self.checkRight(row+step,rows, step, color, right+1,deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        if(key in validSpaces.keys()):
                            validSpaces.pop(key)
                break
            
            elif current.color == color:
                break
            else:
                last = [current]
            
            right += 1

        return validSpaces
    
    def checkKingLeft(self, begin, end, step, color, left, skipped=[]):
        validSpaces = {}
        last = []
        key = ()
        for row in range(begin, end, step):
            if left < 0:
                break
            current = self.board[row][left]
            if current == 0:
                if skipped and not last:
                    break
                elif skipped:
                    validSpaces[(row, left)] = skipped+last
                    skipped += last
                    key = (row,left)
                else:
                    validSpaces[(row, left)] = last
                    key = (row,left)
                
                if last:
                    if step == 1:
                        rows = min(row+3,ROWS)
                        kingrows = max(row-3,-1)
                        kingstep = -1
                    else:
                        rows = max(row-3,-1)
                        kingrows = min(row+3,ROWS)
                        kingstep = 1
                    
                    if len(skipped) == 0:
                        skipped = last

                    siz = len(validSpaces)
                    validSpaces.update(self.checkKingLeft(row+kingstep, kingrows, kingstep, color, left-1, deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        validSpaces.pop(key)
                    siz = len(validSpaces)
                    validSpaces.update(self.checkLeft(row+step,rows, step, color, left-1,deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        if(key in validSpaces.keys()):
                            validSpaces.pop(key)
                    siz = len(validSpaces)
                    validSpaces.update(self.checkRight(row+step,rows, step, color, left+1,deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        if(key in validSpaces.keys()):
                            validSpaces.pop(key)
                break
            
            elif current.color == color:
                break
            else:
                last = [current]
            
            left -= 1

        return validSpaces
    
    def checkKingRight(self, begin, end, step, color, right, skipped=[]):
        validSpaces = {}
        last = []
        key = ()
        for row in range(begin, end, step):
            if right >= COLUMNS:
                break
            current = self.board[row][right]
            if current == 0:
                if skipped and not last:
                    break
                elif skipped:
                    validSpaces[(row, right)] = skipped+last
                    skipped += last
                    key = (row,right)
                else:
                    validSpaces[(row, right)] = last
                    key = (row, right)
                
                if last:
                    if step == 1:
                        rows = min(row+3,ROWS)
                        kingrows = max(row-3,-1)
                        kingstep = -1
                    else:
                        rows = max(row-3,-1)
                        kingrows = min(row+3,ROWS)
                        kingstep = 1
                    
                    if len(skipped) == 0:
                        skipped = last

                    siz = len(validSpaces)
                    validSpaces.update(self.checkKingRight(row+kingstep, kingrows, kingstep, color, right+1, deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        validSpaces.pop(key)
                    siz = len(validSpaces)
                    validSpaces.update(self.checkLeft(row+step,rows, step, color, right-1,deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        if(key in validSpaces.keys()):
                            validSpaces.pop(key)
                    siz = len(validSpaces)
                    validSpaces.update(self.checkRight(row+step,rows, step, color, right+1,deepcopy(skipped)))
                    if(len(validSpaces) > siz):
                        if(key in validSpaces.keys()):
                            validSpaces.pop(key)
                break
            
            elif current.color == color:
                break
            else:
                last = [current]
            
            right += 1

        return validSpaces

    def getValidPieces(self,color):
        moves = {}
        validPieces = []
        for row in range(ROWS):
            for col in range(COLUMNS):
                if self.board[row][col] != 0 and self.board[row][col].color == color:
                    moves = self.getValidSpaces(self.board[row][col])
                    if len(moves) > 0:
                        validPieces.append((row,col))
                    moves.clear()
        return validPieces
    
    def getKillPieces(self,color):
        moves = {}
        killPieces = []
        for row in range(ROWS):
            for col in range(COLUMNS):
                if self.board[row][col] != 0 and self.board[row][col].color == color:
                    moves = self.getValidSpaces(self.board[row][col])
                    if len(moves) > 0:
                        for move in moves:
                            skipped = moves[move]
                            if len(skipped) > 0:
                                killPieces.append((row,col))
                                break
                    moves.clear()
        return killPieces
            
    def checkScore(self):
        score = 2*self.blueRemaining - 2*self.redRemaining + self.blueKings - self.redKings


        return score

    def checkWin(self):
        if self.redRemaining <=0:
            return 'Blue'
        elif self.blueRemaining <= 0:
            return 'Red'
        else:
            return None

    
    # def updateValidSpaces(self,oldDict, newDict):
    #     if len(oldDict) == 0:
    #         return newDict
        
    #     for key in newDict.keys():
    #         if key in oldDict.keys():
    #             continue
    #         else:
    #             oldDict[key] = newDict[key]
        
    #     return oldDict
class Piece:
    def __init__(self, row, col, color):
        self.row = row
        self.col = col
        self.color = color
        self.king = False
        self.x = 0
        self.y = 0
        self.calculatePosition()
        
    def calculatePosition(self):
        self.x = self.col*TILE_SIZE + TILE_SIZE // 2
        self.y = self.row*TILE_SIZE + TILE_SIZE // 2
    
    def makeKing(self):
        self.king = True
    
    def drawPiece(self,window):
        radius = TILE_SIZE//2 - 30
        border = 10
        if self.color == LIGHTRED:
            pygame.draw.circle(window,DARKRED,(self.x,self.y),radius+border)
        else:
            pygame.draw.circle(window,DARKBLUE,(self.x,self.y),radius+border)

        pygame.draw.circle(window,self.color,(self.x,self.y),radius)

        if self.king == True:
            window.blit(CROWN,(self.x - CROWN.get_width()//2, self.y - CROWN.get_height()//2))
    
    def updatePosition(self, row, col):
        self.row = row
        self.col = col
        self.calculatePosition()


    


