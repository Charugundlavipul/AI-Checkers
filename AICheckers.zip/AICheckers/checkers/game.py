import pygame
pygame.init()
import pygame
from checkers.fixedValues import *
from .BoardnPawns import *
# from .piece import Piece

class Game:

    def __init__(self, window):
        self.selectedPiece = None
        self.turn = LIGHTRED
        self.window = window
        self.board = Board()
        self.validSpaces = {}
        self.validPieces = []
        self.killPieces = []
        self.redRemainingPrevMove = 0
        self.blueRemainingPrevMove = 0
        self.redKingsPrevMove = 0
        self.blueKingsPrevMove = 0
        self.moveCounter = 0

        
    
    def updateGame(self):
        self.board.fillPieces(self.window)
        self.drawWindow()
        self.showValidPieces()
        self.showValidSpaces()
        pygame.display.update()
    
    def drawWindow(self):
        pygame.draw.rect(self.window, WHITE, (0,0,HEIGHT,WIDTH), 5)
        radius = TILE_SIZE//2 - 30
        border = 10
        #Pieces Score
        pygame.draw.circle(self.window,DARKRED,(900,350),radius+border)
        pygame.draw.circle(self.window,LIGHTRED,(900,350),radius)
        pygame.draw.circle(self.window,DARKBLUE,(900,450),radius+border)
        pygame.draw.circle(self.window,LIGHTBLUE,(900,450),radius)

        pygame.draw.circle(self.window,DARKRED,(1100,350),radius+border)
        pygame.draw.circle(self.window,LIGHTRED,(1100,350),radius)
        pygame.draw.circle(self.window,DARKBLUE,(1100,450),radius+border)
        pygame.draw.circle(self.window,LIGHTBLUE,(1100,450),radius)

        self.window.blit(CROWN,(1100 - CROWN.get_width()//2, 350 - CROWN.get_height()//2))
        self.window.blit(CROWN,(1100 - CROWN.get_width()//2, 450 - CROWN.get_height()//2))

        myfont = pygame.font.SysFont('monospace',40,bold=1)
        redKilled = 12 - self.board.redRemaining
        blueKilled = 12 - self.board.blueRemaining
        redScoreLabel = myfont.render("x"+str(redKilled),1,WHITE)
        blueScoreLabel = myfont.render("x"+str(blueKilled),1,WHITE)
        self.window.blit(redScoreLabel,(975 - redScoreLabel.get_width()//2, 350 - redScoreLabel.get_height()//2))
        self.window.blit(blueScoreLabel,(975 - blueScoreLabel.get_width()//2, 450 - blueScoreLabel.get_height()//2))

        redKings = self.board.redKings
        blueKings = self.board.blueKings
        redKingsLabel = myfont.render("x"+str(redKings),1,WHITE)
        blueKingsLabel = myfont.render("x"+str(blueKings),1,WHITE)
        self.window.blit(redKingsLabel,(1175 - redKingsLabel.get_width()//2, 350 - redKingsLabel.get_height()//2))
        self.window.blit(blueKingsLabel,(1175 - blueKingsLabel.get_width()//2, 450 - blueKingsLabel.get_height()//2))

        buttonfont = pygame.font.SysFont('monospace',30,bold=1)
        pygame.draw.rect(self.window, LIGHTPEACH, (975,550,125,50))
        resetLabel = buttonfont.render("RESET",1,BROWN)
        self.window.blit(resetLabel,(1038 - resetLabel.get_width()//2, 575 - resetLabel.get_height()//2))

        win = self.checkWin()
        if win != None:
            messagefont = pygame.font.SysFont('monospace',75,bold = 1)
            if win == 'Red':
                messageLabel = messagefont.render("Red Wins",1,LIGHTPEACH)
            else:
                messageLabel = messagefont.render("Blue Wins",1,LIGHTPEACH)
            self.window.blit(messageLabel,(1050 - messageLabel.get_width()//2, 150 - messageLabel.get_height()//2))
        
        elif self.checkDraw():
            messagefont = pygame.font.SysFont('monospace',75,bold = 1)
            messageLabel = messagefont.render("Draw",1,LIGHTPEACH)
            self.window.blit(messageLabel,(1050 - messageLabel.get_width()//2, 150 - messageLabel.get_height()//2))
        # messagefont = pygame.font.SysFont('monospace',70,bold = 1)
        # messageLabel = messagefont.render("Red Wins",1,LIGHTPEACH)
        # self.window.blit(messageLabel,(1050 - messageLabel.get_width()//2, 150 - messageLabel.get_height()//2))


    def resetGame(self):
        self.selectedPiece = None
        self.turn = LIGHTRED
        self.board = Board()
        self.validSpaces = {}

    def selectPiece(self, row, col):
        if self.selectedPiece:
            result = self.move(row, col)
            if result == False:
                self.selectedPiece = None
                self.selectPiece(row, col)
        
        piece = self.board.getPiece(row, col)
        if piece != 0 and self.turn == piece.color:
            self.selectedPiece = piece
            self.validSpaces = self.board.getValidSpaces(piece,self.killPieces)
            return True

        return False

    def move(self, row, col):
        piece = self.board.getPiece(row, col)
        row1, col1 = self.selectedPiece.row, self.selectedPiece.col
        if self.selectedPiece and (row1,col1) in self.validPieces and piece == 0 and (row, col) in self.validSpaces:
            self.board.movePiece(self.selectedPiece, row, col)
            skipped = self.validSpaces[(row,col)]
            self.board.removePieces(skipped)
            self.switchPiece()
            return True
        
        else:
            return False

    def switchPiece(self):
        if self.board.redRemaining == self.redRemainingPrevMove and self.board.blueRemaining == self.blueRemainingPrevMove:
            if self.board.redKings == self.redKingsPrevMove and self.board.blueKings == self.blueKingsPrevMove:
                self.moveCounter += 1
            else:
                self.redKingsPrevMove = self.board.redKings
                self.blueKingsPrevMove = self.board.blueKings
                self.moveCounter = 0
        else:
            self.redRemainingPrevMove = self.board.redRemaining
            self.blueRemainingPrevMove = self.board.blueRemaining
            self.moveCounter = 0
        
        self.validSpaces = {}
        if self.turn == LIGHTRED:
            self.turn = LIGHTBLUE
        else:
            self.turn = LIGHTRED
        
    def showValidSpaces(self):
        for space in self.validSpaces.keys():
            if self.selectedPiece != None:
                row1, col1 = self.selectedPiece.row, self.selectedPiece.col
                if (row1,col1) in self.validPieces:
                    row, col = space
                    pygame.draw.circle(self.window,BLUE, (col*TILE_SIZE + TILE_SIZE // 2,row*TILE_SIZE + TILE_SIZE // 2),15)
    
    def showValidPieces(self):
        self.killPieces = self.board.getKillPieces(self.turn)
        self.validPieces = self.killPieces
        if len(self.validPieces) == 0:
            self.validPieces = self.board.getValidPieces(self.turn)
        for (row,col) in self.validPieces:
            pygame.draw.rect(self.window, YELLOW, (col*100,row*100,TILE_SIZE,TILE_SIZE), 5)

    def checkWin(self):
        return self.board.checkWin()

    def returnBoard(self):
        return self.board
    
    def aiturn(self, board):
        self.board = board
        self.switchPiece()
    
    def checkDraw(self):
        if self.moveCounter >= 50:
            return True
        elif len(self.validPieces) == 0:
            return True
        else: 
            return False
    
    
            

        

       


    