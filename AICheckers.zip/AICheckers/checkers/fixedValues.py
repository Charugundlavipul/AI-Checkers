import pygame
import pygame.font

WIDTH = 800
HEIGHT = 800
TILE_SIZE = 100
ROWS = 8
COLUMNS = 8

BROWN = (112,24,3) #165,42,42 | 83,32,32 | 139,33,7
PEACH = (236,201,131)
LIGHTPEACH = (250,237,175)
DARKRED = (227,38,54)
LIGHTRED = (246,205,199) #255,228,196
DARKBLUE = (13,105,248) # 54,38,227 #67,96,201
LIGHTBLUE = (193,237,244) #240,248,255
BLUE = (0,0,255)
WHITE = (255,255,255)
BLACK = (0,0,0)
YELLOW = (255,255,0)

crown = pygame.image.load('checkers/images/crown1.png')
CROWN = pygame.transform.scale(crown,(35,25))


