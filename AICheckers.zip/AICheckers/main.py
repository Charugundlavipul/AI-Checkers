import pygame
from pygame.constants import MOUSEBUTTONDOWN
from checkers.fixedValues import *
from checkers.BoardnPawns import *
from checkers.game import Game
from AIAlgos import Algorithms


WINDOW = pygame.display.set_mode((1300,WIDTH))
pygame.display.set_caption("Checkers")


def get_row_col_from_mouse(pos):
    x, y = pos
    row = y // TILE_SIZE
    col = x // TILE_SIZE
    return row, col


def main():
    game = Game(WINDOW)
    gameStillGoing = True
    clk = pygame.time.Clock()
    while gameStillGoing:
        clk.tick(10)
        if game.turn == LIGHTBLUE:
            score, board = Algorithms.minimax(game.returnBoard(), 3, True) #minimax
            # board = Algorithms.randomMove(game.returnBoard())
            game.aiturn(board)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameStillGoing = False
            if event.type == MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                x, y = pos
                if x >= 975 and x <= 1100:
                    if y >= 550 and y <= 600:
                        game.resetGame()
                row, col = get_row_col_from_mouse(pos)
                if(col > 7):
                    continue
                game.selectPiece(row, col)

        game.updateGame()
        if game.checkWin():
            print(game.checkWin()+' wins')
            while True:
                flag = False
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        flag = True
                        gameStillGoing = False
                        break
                    elif event.type == MOUSEBUTTONDOWN:
                        pos = pygame.mouse.get_pos()
                        x, y = pos
                        if x >= 975 and x <= 1100:
                            if y >= 550 and y <= 600:
                                game.resetGame()
                                flag = True
                if flag:
                    break
        if game.checkDraw():
            while True:
                flag = False
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        flag = True
                        gameStillGoing = False
                        break
                    elif event.type == MOUSEBUTTONDOWN:
                        pos = pygame.mouse.get_pos()
                        x, y = pos
                        if x >= 975 and x <= 1100:
                            if y >= 550 and y <= 600:
                                game.resetGame()
                                flag = True
                if flag:
                    break

    pygame.quit()

main()

    