import pygame
from checkers.fixedValues import *
from checkers.BoardnPawns import *
# from checkers.piece import *
from checkers.game import *
import copy
from copy import deepcopy
from pygame import Surface
import random

def minimax(board, depth, aiturn):
    if depth <= 0 or board.checkWin() != None:
        score = board.checkScore()
        return score, board
    
    if aiturn:
        maxScore = float('-inf')
        bestMove = None
        for move in possibleMoves(board, LIGHTBLUE):
            score = minimax(move, depth-1, False)[0]
            # if alpha <= score:
            #     alpha = score
            #     bestMove = move
            # if beta <= alpha:
            #     break
            maxScore = max(maxScore, score)
            if maxScore == score:
                bestMove = move
            
        return maxScore, bestMove
    
    else:
        minScore = float('+inf')
        bestMove = None
        for move in possibleMoves(board, LIGHTRED):
            # moveCopy = move
            # killPieces = move.getKillPieces(LIGHTBLUE)
            # if len(killPieces) != 0:
            #     moveCopy = deepcopy(move)
            #     piece = moveCopy.getPiece(killPieces[0][0], killPieces[0][1])
            #     killSpaces = moveCopy.getValidSpaces(piece, killPieces)
            #     move = 0
            #     for i in killSpaces.keys():
            #         move = i
            #         break
            #     moveCopy.movePiece(piece,move[0], move[1])
            #     moveCopy.removePieces(killSpaces[move])
            score = minimax(move, depth-1, True)[0]
            # if score <= beta:
            #     beta = score
            #     bestMove = move
            # if beta <= alpha:
            #     break
            minScore = min(minScore, score)
            if minScore == score:
                bestMove = move
            
        return minScore, bestMove
            
def possibleMoves(board, color):
    possibleMoves = []
    killPieces = board.getKillPieces(color)
    validPieces = killPieces
    if len(validPieces) == 0:
        validPieces = board.getValidPieces(color)
    
    for (row,col) in validPieces:
        piece = board.getPiece(row,col)
        validSpaces = board.getValidSpaces(piece,killPieces)
        for move, skipPieces in validSpaces.items():
            boardCopy = deepcopy(board)
            pieceCopy = boardCopy.getPiece(row, col)
            simulateMove(pieceCopy, move, boardCopy, skipPieces)
            possibleMoves.append(boardCopy)
    
    return possibleMoves

def simulateMove(piece, move, board, skipPieces):
    board.movePiece(piece, move[0], move[1])
    if len(skipPieces) > 0:
        board.removePieces(skipPieces)
    
    return board

def randomMove(board):
    moves = possibleMoves(board, LIGHTBLUE)
    if len(moves) <= 0:
        return
    rand = random.randint(0,len(moves)-1)
    print(rand,len(moves))
    move = moves[rand]
    return move


